package com.university.accountstracker.model;

import java.util.HashSet;
import java.util.Set;

public class User {
    private String username;
    private String password; // Will store ENCODED password
    private String email;
    private Set<String> roles = new HashSet<>();
    private boolean enabled = true;

    public User(String username, String password, String email, String... roles) {
        this.username = username;
        this.password = password; // Raw password initially, will be encoded by service
        this.email = email;
        for (String role : roles) {
            this.roles.add(role);
        }
    }
    
    public User(String username, String password, String... roles) { // For admin
        this.username = username;
        this.password = password; // Raw password initially
        this.email = null; 
         for (String role : roles) {
            this.roles.add(role);
        }
    }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; } // Service will set encoded password
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public Set<String> getRoles() { return roles; }
    public void setRoles(Set<String> roles) { this.roles = roles; }
    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
}
