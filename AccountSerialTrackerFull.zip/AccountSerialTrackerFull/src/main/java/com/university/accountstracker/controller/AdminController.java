package com.university.accountstracker.controller;

import com.university.accountstracker.model.QueueSerials;
import com.university.accountstracker.service.SerialService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/admin")
public class AdminController {

    private final SerialService serialService;

    @Autowired
    public AdminController(SerialService serialService) {
        this.serialService = serialService;
    }

    @PostMapping("/serial/next")
    public String nextSerial(@RequestParam("queueType") String queueTypeStr, RedirectAttributes redirectAttributes) {
        try {
            QueueSerials.QueueType queueType = QueueSerials.QueueType.valueOf(queueTypeStr.toUpperCase());
            serialService.incrementSerial(queueType);
            redirectAttributes.addFlashAttribute("message", formatQueueName(queueType) + " serial incremented!");
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("error", "Invalid queue type specified.");
        }
        return "redirect:/admin";
    }

    @PostMapping("/serial/set")
    public String setSerial(@RequestParam("queueType") String queueTypeStr,
                            @RequestParam("serialValue") int serial,
                            RedirectAttributes redirectAttributes) {
        try {
            QueueSerials.QueueType queueType = QueueSerials.QueueType.valueOf(queueTypeStr.toUpperCase());
            if (serial >= 0) {
                serialService.setSerial(queueType, serial);
                redirectAttributes.addFlashAttribute("message", formatQueueName(queueType) + " serial set to " + serial + "!");
            } else {
                redirectAttributes.addFlashAttribute("error", "Invalid serial number for " + formatQueueName(queueType) + ".");
            }
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("error", "Invalid queue type specified for setting value.");
        }
        return "redirect:/admin";
    }
    
    @PostMapping("/serial/reset-all")
    public String resetAllSerials(RedirectAttributes redirectAttributes) {
        serialService.resetAllSerials();
        redirectAttributes.addFlashAttribute("message", "All serial numbers have been reset to 0.");
        return "redirect:/admin";
    }

    private String formatQueueName(QueueSerials.QueueType queueType) {
        switch (queueType) {
            case TUITION_FEE: return "Tuition Fee";
            case HALL_FEE: return "Hall Fee";
            case CLEARANCE: return "Clearance";
            default: return "Unknown Queue";
        }
    }
}
